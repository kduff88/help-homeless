<div class="col footer">
	<div class="row">
		<div class="col-md-3"><div class="footer-copy">© Copyright 2018 Help the Homeless.</div></div>
		<div class="col-md-3">&nbsp;</div>
		<div class="col-md-3">&nbsp;</div>
		<div class="col-md-3 footer-address">Contact Us: <br />
			The Treasurer <br />
			Care of HW Associates<br />
			Portmill House,<br />
			Portmill Lane,<br />
			Hitchin, <br />
			Hertfordshire <br />
			SG5 1DJ
			<p>
				Tele No: 01462 435835
			</p>
		</div>
	</div>
</div>