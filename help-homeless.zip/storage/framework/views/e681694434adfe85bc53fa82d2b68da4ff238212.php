<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body class="bg-body">
      <div id="app">
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <header class="row">
 
               <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
           </header>

            <div class="content">
              <div class="row">
                <div class="col-md-8 offset-md-2">
                 <div class="sub-heading"><h2><p>Volunteer</p></h2></div>
                 <div class="paper">
                  <h4>Volunteering:</h4>
                  <br />
                  <p>
                    We are always grateful for any time volunteers can provide to help support our service users. We are usually in need of people to help with:  
                  </p>
                  <p>
                    &#9830; Fund Raising Activities<br />
                    &#9830; Publicity / PR<br />
                    &#9830; DIY – indoor & outdoor<br />
                    &#9830; Transportation<br />
                    &#9830; Admin / Clerical<br />
                    &#9830; Finance / Accounts<br />
                  </p>
                  <p>
                    We provide relevant guidance for all of our volunteers and continued support from all staff. If you are interested in learning more about how you can help Helping Herts Homeless.
                  </p>
                  <p>
                    <hr />
                  </p>
                  <p>
                    <h4>Volunteer Form:</h4>
                    <br />
                  </p>
                  <p>
                  This is still being created, please send an email at <b>volunteering@helpinghertshomeless.org.uk</b> if you would like to sign up to volunteer.
                  </p>
                 </div>
                </div>
              </div>
            </div>

            <footer class="row">
 
               <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
           </footer>
        </div>
      </div>
        <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
    </body>
</html>
