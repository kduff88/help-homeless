<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body class="bg-body">
      <div id="app">
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <header class="row">
 
               <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
           </header>

            <div class="content">
              <div class="row">
                <div class="col-md-8 offset-md-2">
                 <div class="sub-heading"><h2><p>Our Team</p></h2></div>
                 <div class="paper">
                  <h4>Who We Work With:</h4>
                  <p>
                    We work with any organisation in the North Herts and surrounding area that provides services or advice to the homeless and vulnerable.  This includes North Herts District Council,  Stevenage Haven, Aldwyck Young Persons Services, Herts Young Homeless and Homeless Link.
                  </p>
                 </div>
                </div>
              </div>
            </div>

            <footer class="row">
 
               <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
           </footer>
        </div>
      </div>
        <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
    </body>
</html>
