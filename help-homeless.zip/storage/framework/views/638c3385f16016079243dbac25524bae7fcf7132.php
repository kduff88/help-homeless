<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body class="bg-body">
      <div id="app">
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <header class="row">
 
               <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
           </header>

            <div class="content">
              <div class="row">
                <div class="col-md-8 offset-md-2">
                 <div class="sub-heading"><h2><p>About Us</p></h2></div>
                 <div class="paper">
                  <h4>Helping Herts Homeless:</h4>
                  <h6><b>(the working name of The North Herts Sanctuary)</b></h6>
                  <br />
                  <p>
                    Many people have supported the North Herts Sanctuary charity since its inception in 1992. Our new working name in September 2018 to Helping Herts Homeless reflects the charity’s new direction and focus. The charity will in addition to providing temporary accommodation for those who are homeless, act as a hub in supporting other charities and organisations who are directly involved in alleviating homelessness.
                  </p>
                  <h4>Mission:</h4>
                  <p>
                    Working together with other agencies, we aim to support the provision of emergency accommodation and other support services, to anyone in Hertfordshire who has become homeless or is at risk of homelessness. Our aim, for every client, is that they are assisted and supported towards the means to move onto a secure, settled and fulfilling life.
                  </p>
                 </div>
                </div>
              </div>
            </div>

            <footer class="row">
 
               <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
           </footer>
        </div>
      </div>
        <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
    </body>
</html>
